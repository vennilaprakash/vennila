package com.training;

public class datanotfoundException extends RuntimeException {
	datanotfoundException(String s)
	{
		super(s);
	}

}
