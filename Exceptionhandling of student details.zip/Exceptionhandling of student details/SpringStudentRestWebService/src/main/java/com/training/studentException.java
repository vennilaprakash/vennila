package com.training;

public class studentException extends Exception{
	private String errorMessage;

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	public studentException()
	{
		super();
	}
	public studentException(String error)
	{
		super(error);
		this.errorMessage=error;
	}

}
