package com.training;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class StudentService {

	@Autowired
	StudentJDBCTemplate studentDAOImpl;

   	

    @RequestMapping(value="student/{id}",method = RequestMethod.GET)
    public @ResponseBody ResponseEntity<Student> getStudent(@PathVariable int id) throws studentException{
    	Student s=null;
          s= studentDAOImpl.getStudent(id);
         
          if(s==null)
        	  throw new studentException("Invalid Id!!!!!");
          return new  ResponseEntity<Student>(s,HttpStatus.OK);
    }
   
    
    @RequestMapping(value="/student",method = RequestMethod.GET) 
	public @ResponseBody List<Student> getAllBookDetails(ModelMap model){
		List bookList = null;
		bookList = (List) studentDAOImpl.getAllStudent();
		return bookList ;
		
	}
    @RequestMapping(value="student/{id}",method = RequestMethod.DELETE)
    public @ResponseBody ResponseEntity<Student> deleteStudent(@PathVariable("id") int id) throws studentException{
    Student s=studentDAOImpl.getStudent(id);
	if(s==null)
	  throw new studentException("Invalid Id!!!");
	  studentDAOImpl.deleteStudent(id);
      return new  ResponseEntity<Student>(s,HttpStatus.OK);
      
    }
    @RequestMapping(value="/student/{id}",method = RequestMethod.PUT)  
	public @ResponseBody ResponseEntity<Student> updateStudentDetails(@RequestBody Student student,@PathVariable int id) throws studentException{
    	 Student s=studentDAOImpl.getStudent(id);
    	 if(s==null)
    		 throw new studentException("Invalid Id!!!");
    	studentDAOImpl.updateStudentDetails(student,id);
		 s=studentDAOImpl.getStudent(id);
		 return new  ResponseEntity<Student>(s,HttpStatus.OK);
	      
		
	}
    
	
	@RequestMapping(value = "/student", method = RequestMethod.POST)
	public @ResponseBody Student createStudent(@RequestBody Student student){
		
		
		studentDAOImpl.createStudent(student);
		
		return  student;
		
	}
	@ExceptionHandler(studentException.class)      

    public ResponseEntity<errorResponse> exceptionHandler(Exception ex) {       

                errorResponse error = new errorResponse();      

                error.setErrorCode(HttpStatus.PRECONDITION_FAILED.value());     

                error.setMessage(ex.getMessage());      

                return new ResponseEntity<errorResponse>(error, HttpStatus.OK); 

            }   


	
}
