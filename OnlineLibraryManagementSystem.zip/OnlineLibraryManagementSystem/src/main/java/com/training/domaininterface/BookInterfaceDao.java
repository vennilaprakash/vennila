package com.training.domaininterface;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import com.training.domain.BookBean;
public interface BookInterfaceDao
{

	 
	   public List getAllBooks();
	   public void updateBookDetails(BookBean book,Integer id);
	   public void deleteBook(Integer id);
	   public void insertBook(BookBean book);
	   public BookBean getBook(Integer id);
	   public String fineCalculation(Integer id) throws ParseException;
	 //  public String mail(Integer id);
}
