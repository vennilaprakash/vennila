package com.training.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.sql.DataSource;

import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;

import com.training.domain.BookBean;
import com.training.domain.UserBean;
import com.training.domaininterface.BookInterfaceDao;
import com.training.mapper.BookMapper;
import com.training.mapper.UserMapper;

public class BookDao implements BookInterfaceDao{
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	private Integer id;
	
	   public void setDataSource(DataSource dataSource) {
	      this.dataSource = dataSource;
	      this.jdbcTemplateObject = new JdbcTemplate(dataSource);
	   }
	public List getAllBooks() {
		List booklist=null;
		 String SQL = "select * from xbbnhhc_Books";
		 booklist= jdbcTemplateObject.query(SQL, new Object[]{}, new BookMapper());
	      return booklist;
		
	}

	public void updateBookDetails(BookBean bookbean, Integer id) {
	
		
			String sql="update xbbnhhc_Books set bookid="+bookbean.getBookID()+",bookisbn="+bookbean.getBookISBN()+",bookname='"+bookbean.getBookName()+"',authorname='"+bookbean.getAuthorName()+"',yearofpublication='"+bookbean.getYearofPublication()+"',edition='"+bookbean.getEdition()+"' where bookid="+id;
			 System.out.println("sql "+sql);	
			 jdbcTemplateObject.update(sql);
			}
			
	

	public void deleteBook(Integer id) {
		String sql= "delete from xbbnhhc_Books where bookid = "+id;
		jdbcTemplateObject.update(sql);
		
	}

	public void insertBook(BookBean bookbean) {
		String sql="insert into xbbnhhc_Books values("+bookbean.getBookID()+","+bookbean.getBookISBN()+",'"+bookbean.getBookName()+"','"+bookbean.getAuthorName()+"','"+bookbean.getYearofPublication()+"','"+bookbean.getEdition()+"')";
		jdbcTemplateObject.update(sql);
		
	}
	public BookBean getBook(Integer bookid) {
		BookBean bookbean=null;
		 String SQL = "select * from xbbnhhc_Books where bookid =?";
		 bookbean = jdbcTemplateObject.queryForObject(SQL, new Object[]{bookid}, new BookMapper());
	      return bookbean;
	}
	public String fineCalculation(Integer id) throws ParseException {
	     UserBean userbean=null;
		 String SQL = "select * from user_details where userbookid =?";
		 userbean = jdbcTemplateObject.queryForObject(SQL, new Object[]{id}, new UserMapper());
		 Date issue=userbean.getDateofissue();
		 Date returnbook=userbean.getDateofreturn();
	     DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	      long numberOfDays = (issue.getTime()-returnbook.getTime())/86400000;
	      long noofdays=Math.abs(numberOfDays);
	      int mail=(int) (noofdays-15);
	      
	      if(noofdays>15)
	      {
	      int f=(int) (noofdays-15);
	      String s=String.valueOf(f);
	      return "Fine = "+s;
	      }
	      
	     else
	     {
	    	 return "Fine = 0";
	     }
		
	}
	/*public String mail(Integer id) {
		 UserBean userbean=null;
		 String SQL = "select * from user_details where userbookid =?";
		 userbean = jdbcTemplateObject.queryForObject(SQL, new Object[]{id}, new UserMapper());
		 Date issue=userbean.getDateofissue();
		 Date returnbook=userbean.getDateofreturn();
	     DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	      long numberOfDays = (issue.getTime()-returnbook.getTime())/86400000;
	      long noofdays=Math.abs(numberOfDays);
	      int mail=(int) (noofdays-15);
	      
	      if(mail>=0&&mail<=2)
	      {
	    	  String to = "vprakashreddy@inautix.co.in"; 
	          String from = "shmurali@inautix.co.in";
	          String host = "172.24.34.118";//or IP address  
	      
	         //Get the session object  
	          Properties properties = System.getProperties();  
	          properties.setProperty("mail.smtp.host", host);  
	          Session session = Session.getDefaultInstance(properties);  
	      
	         //compose the message  
	          try{  
	             MimeMessage message = new MimeMessage(session);  
	             message.setFrom(new InternetAddress(from));  
	             message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
	             message.setSubject("Ping");  
	             message.setText("Due date to return book is going to end");  
	      
	             // Send message  
	             Transport.send(message);  
	             System.out.println("message sent successfully....");  
	      
	          }catch (MessagingException mex) {mex.printStackTrace();}  
	        
	      return "The mail has been send to the receiptant";
	      }
	      
	     else
	     {
	    	 return "The mail has not been send to the receiptant";
	     }
		
	}
	
*/
}
