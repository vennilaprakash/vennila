package com.training.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.domain.BookBean;
import com.training.domain.UserBean;

public class UserMapper implements RowMapper<UserBean>{

	public UserBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		UserBean userbean=new UserBean();
		userbean.setUserid(rs.getInt("userid"));
		userbean.setUsername(rs.getString("username"));
		userbean.setUserbookid(rs.getInt("userbookid"));
		userbean.setAddress(rs.getString("address"));
		userbean.setDateofissue(rs.getDate("dateofissue"));
		userbean.setDateofreturn(rs.getDate("dateofreturn"));
		userbean.setEmail(rs.getString("email"));
		return userbean;
	}

}
