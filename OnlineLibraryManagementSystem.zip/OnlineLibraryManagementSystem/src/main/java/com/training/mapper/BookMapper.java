package com.training.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.training.domain.BookBean;


public class BookMapper implements RowMapper<BookBean> {

	public BookBean mapRow(ResultSet rs, int rowNum) throws SQLException {
		BookBean bookbean=new BookBean();
		bookbean.setBookID(rs.getInt("bookID"));
		bookbean.setBookISBN(rs.getInt("bookISBN"));
		bookbean.setBookName(rs.getString("bookName"));
		bookbean.setAuthorName(rs.getString("authorName"));
		bookbean.setYearofPublication(rs.getString("YearofPublication"));
		bookbean.setEdition(rs.getString("Edition"));
		return bookbean;
	}

}
