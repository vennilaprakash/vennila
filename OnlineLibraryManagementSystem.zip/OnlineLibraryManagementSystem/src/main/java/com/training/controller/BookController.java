package com.training.controller;

import java.text.ParseException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.training.dao.BookDao;
import com.training.domain.BookBean;
import com.training.domain.UserBean;

@Controller
public class BookController {
	@Autowired
	BookDao bookdao;
	@RequestMapping(value="/books",method = RequestMethod.GET) 
	public @ResponseBody List<BookBean> getAllBookDetails(){
		List bookList = null;
		bookList = (List) bookdao.getAllBooks();
		return bookList ;
	}
	
	 @RequestMapping(value="books/{bookid}",method = RequestMethod.GET)
	    public @ResponseBody BookBean getBook(@PathVariable int bookid){
	    	BookBean bookbean=null;
	    	bookbean=bookdao.getBook(bookid);
	        return bookbean;
	    }
	 @RequestMapping(value="users/{bookid}",method = RequestMethod.GET,produces = "application/json")
	    public  @ResponseBody String fineCalculation(@PathVariable int bookid) throws ParseException{
	    	String str;
	    	str=bookdao.fineCalculation(bookid);
	        return str;
	    }
	
	
	@RequestMapping(value = "/books", method = RequestMethod.POST)
	public @ResponseBody BookBean createStudent(@RequestBody BookBean bookbean){
		bookdao.insertBook(bookbean);
		return  bookbean;
	}
	
	 @RequestMapping(value="/books/{bookid}",method = RequestMethod.PUT)  
		public @ResponseBody BookBean updateBookDetails(@RequestBody BookBean bookbean,@PathVariable int bookid) {
		 bookdao.updateBookDetails(bookbean, bookid);
		 BookBean book=bookdao.getBook(bookid);
	    return book;
		      
	}
	 @RequestMapping(value="books/{bookid}",method = RequestMethod.DELETE)
	    public @ResponseBody BookBean deleteStudent(@PathVariable int bookid) {
		 BookBean book=bookdao.getBook(bookid);
		 bookdao.deleteBook(bookid);
	      return book;
	      
	    }
	    
	
}
