package com.training.domain;

import java.util.Date;

public class UserBean {
	int userid;
	String username;
	int userbookid;
	String address;
	Date dateofissue;
	Date dateofreturn;
	String email;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getUserbookid() {
		return userbookid;
	}
	public void setUserbookid(int userbookid) {
		this.userbookid = userbookid;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Date getDateofissue() {
		return dateofissue;
	}
	public void setDateofissue(Date dateofissue) {
		this.dateofissue = dateofissue;
	}
	public Date getDateofreturn() {
		return dateofreturn;
	}
	public void setDateofreturn(Date dateofreturn) {
		this.dateofreturn = dateofreturn;
	}
	

}
