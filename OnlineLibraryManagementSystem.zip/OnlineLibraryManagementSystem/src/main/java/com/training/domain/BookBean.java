package com.training.domain;

public class BookBean {
	int bookID;
	int bookISBN;
	String bookName;
	String authorName;
	String YearofPublication;
	String Edition;
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public int getBookISBN() {
		return bookISBN;
	}
	public void setBookISBN(int bookISBN) {
		this.bookISBN = bookISBN;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getYearofPublication() {
		return YearofPublication;
	}
	public void setYearofPublication(String yearofPublication) {
		YearofPublication = yearofPublication;
	}
	public String getEdition() {
		return Edition;
	}
	public void setEdition(String edition) {
		Edition = edition;
	}
	
	

}
