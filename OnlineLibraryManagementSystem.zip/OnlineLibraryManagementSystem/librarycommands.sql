create table xbbnhhc_Books(bookid int,bookisbn int,bookname varchar(30),authorname varchar(30),yearofpublication varchar(30),edition varchar(30));
insert into xbbnhhc_Books values(1,101,'Let us C','yeswant kanetkar','2014','5th Edition');
insert into xbbnhhc_Books values(2,102,'Java','James Gosling','2000','2nd Edition');
select * from xbbnhhc_books;
delete from xbbnhhc_books;

create table user_details(userid int,username varchar(20),userbookid int,address varchar(50),dateofissue date,dateofreturn date,email varchar(50));
insert into user_details values(1,'vennila',1,'hosur','2017-06-16','2017-07-17','vprakashreddy@inautix.co.in');
insert into user_details values(2,'navya',2,'andra','2017-06-16','2017-06-25','sapenukonda@inautix.co.in');
insert into user_details values(3,'shruthi',3,'salem','2017-06-15','2017-06-25');
drop table user_details;